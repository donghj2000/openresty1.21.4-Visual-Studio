#! /bin/sh
# This is a generated file.
srcdir=D:/Anaconda3/MyCode/Nginx/openresty-1.21.4.1/objs/lib/pcre-8.45
pcregrep=D:/Anaconda3/MyCode/Nginx/openresty-1.21.4.1/objs/lib/pcre-8.45/DEBUG/pcregrep.exe
pcretest=D:/Anaconda3/MyCode/Nginx/openresty-1.21.4.1/objs/lib/pcre-8.45/DEBUG/pcretest.exe
. D:/Anaconda3/MyCode/Nginx/openresty-1.21.4.1/objs/lib/pcre-8.45/RunGrepTest
if test "$?" != "0"; then exit 1; fi
# End
